<!doctype html>

<html>
<head>
	<title></title>
	<style>
		body {
			background: url(images.jpg) no-repeat center center fixed; 
		    -webkit-background-size: cover;
		    -moz-background-size: cover;
		    -o-background-size: cover;
		    background-size: cover;
			}
	    .box{
			width:400px;
			height:400px;
			background: rgba(0,0,0,0,4);
			padding:40px;
			color: black;
			margin: 0 auto;
			marging-top:140px;
			text-align:center;
		}
	
		.asd{
		    text-decoration: none;
			margin:7px 7px 10px 7px;
			background-color:white;
			text-align: center;
			padding-bottom: 7px;
			padding-top: 7px;
			color: black;
			font-size: 25px;
		}	
		p{
		color:black;
		}
		a{
		color:black;
		}
	</style>
		
</head>

<body  >
	<div class="asd">
		<p><i>Welcome To Home Rent System</i></p>
		<p></p>
	</div>
	<div class="box" >
	<p>Some people look for a beutiful place,Others make a place beautiful...<p>
	</div>
	
	<p style="text-align:center">To go next page click here:<a href="nextpage.php" target="_self">nextpage</a> </p>  
	</body>
	</html>